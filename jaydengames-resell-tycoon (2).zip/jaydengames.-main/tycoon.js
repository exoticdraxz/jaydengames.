(() => {
  'use strict';
  const STOCK=[
    {name:'Sneaker box',buy:24,sell:37,level:1},
    {name:'Collector deck',buy:68,sell:104,level:2},
    {name:'Vintage console',buy:130,sell:190,level:3}
  ];
  const LEVELS=[
    {name:'Run-down shop',sign:'OLD RESALE',cap:3,cost:180},{name:'Corner shop',sign:'CORNER SHOP',cap:6,cost:400},
    {name:'Market outlet',sign:'MARKET OUTLET',cap:10,cost:850},{name:'Flagship',sign:'RESELL FLAGSHIP',cap:16,cost:0}
  ];
  const PRESETS={
    Low:{resolution:.78,pixels:320000,dpr:1,distance:18,shadows:false,detail:0},
    Medium:{resolution:1,pixels:660000,dpr:1.2,distance:24,shadows:true,detail:1},
    High:{resolution:1,pixels:1100000,dpr:1.5,distance:32,shadows:true,detail:2}
  };
  const STATIONS=[
    {x:-7,z:-5.5,foot:-2.65,kind:'buy',name:'BUY STOCK',color:'#84f5bb',roof:'#21b86d',side:'#287e5e',wall:'#55aa81'},
    {x:0,z:-5.5,foot:-2.65,kind:'sell',name:'SELL STOCK',color:'#ffdc6b',roof:'#ffad3c',side:'#bd6730',wall:'#e28b36'},
    {x:7,z:-5.5,foot:-2.65,kind:'upgrade',name:'BUILD SHOP',color:'#d7ccff',roof:'#8b68ee',side:'#5944ad',wall:'#775dcd'}
  ];
  const PLOT={x:-6.4,z:7.05};
  const MARKET={x:0,z:2.5,yaw:0,pitch:-.055},START={x:PLOT.x,z:PLOT.z-8.6,yaw:Math.PI,pitch:.08};
  const EYE=1.68,CLIP=.15,clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
  const CUSTOMER_LINES=[
    ['This shop looks cooked.', 'Lowkey got potential.', 'Patch that roof, bro.'],
    ['Okay, you locked in.', 'No cap, this is clean.', 'That conveyor is a W.'],
    ['This shop has aura.', 'Not glazing, this is fire.', 'That display understood the assignment.'],
    ['Elite aura, no notes.', 'This flagship ate.', 'I fear you cleared.']
  ];
  const keyDir={w:'up',arrowup:'up',s:'down',arrowdown:'down',a:'left',arrowleft:'left',d:'right',arrowright:'right'};
  const money=n=>`$${n.toLocaleString('en-US')}`;
  const fresh=()=>({cash:120,level:1,stock:[0,0,0],profit:0,sold:0});
  const settings={preset:'Low',distance:18,shadows:false,fps:true,auto:true,sensitivity:1};
  let state=fresh();
  let savedPlayer={...START};

  function saveCode(){
    return 'RT1.'+btoa(JSON.stringify([state.cash,state.level,...state.stock,state.profit,state.sold]));
  }
  function readCode(code){
    const source=code.trim();
    if(!/^RT1\.[A-Za-z0-9+/=]{8,100}$/.test(source))return null;
    try{
      const data=JSON.parse(atob(source.slice(4)));
      if(!Array.isArray(data)||data.length!==7||!data.every(n=>Number.isSafeInteger(n)&&n>=0&&n<100000000))return null;
      const [cash,level,a,b,c,profit,sold]=data,shop=LEVELS[level-1];
      if(!shop||a+b+c>shop.cap||(b&&level<2)||(c&&level<3))return null;
      return {cash,level,stock:[a,b,c],profit,sold};
    }catch{return null}
  }
  // Standalone builds can keep a checkpoint in their own URL. Sandbox previews
  // still use session progress and portable codes without touching host storage.
  let addressSave=window.self===window.top&&(!location.hash||location.hash.startsWith('#rt='));
  if(addressSave&&location.hash.startsWith('#rt='))state=readCode(location.hash.slice(4))||state;
  function checkpoint(){
    if(!addressSave)return;
    try{history.replaceState(null,'',`#rt=${saveCode()}`)}catch{addressSave=false}
  }

  function mount(area){
    area.innerHTML=`<div class="rt">
      <div class="rt-hud" aria-label="Shop statistics">
        <div class="rt-stat"><span>Wallet</span><strong data-cash>$120</strong></div>
        <div class="rt-stat"><span>Stock</span><strong data-stock>0 / 3</strong></div>
        <div class="rt-stat"><span>Shop tier</span><strong data-level>Level 1</strong></div>
        <button class="rt-button" data-settings>Settings</button>
      </div>
      <div class="rt-grid">
        <section class="rt-world" aria-label="Market Row">
          <div class="rt-view"><canvas tabindex="0" aria-label="First-person view of Market Row. Move with WASD or arrow keys. Press E near a lit pad to trade. Drag to look around."></canvas><span class="rt-plaque">MARKET ROW</span><span class="rt-fps" data-fps>FPS · idle</span></div>
          <div class="rt-world-note"><span data-hint><strong>WASD / arrows</strong> move · <strong>E</strong> interact · Drag to look</span><div class="rt-view-actions"><button class="rt-button" data-shop-view>Your shop</button><button class="rt-button" data-market-view>Market</button><button class="rt-button" data-center>Recenter</button></div></div>
          <div class="rt-touch" aria-label="Touch controls"><div class="rt-dpad">
            <button class="rt-button" data-dir="up" aria-label="Move up">↑</button><button class="rt-button" data-dir="left" aria-label="Move left">←</button>
            <button class="rt-button" data-dir="down" aria-label="Move down">↓</button><button class="rt-button" data-dir="right" aria-label="Move right">→</button>
          </div><button class="rt-button" data-interact>Interact</button></div>
        </section>
        <aside class="rt-panel" aria-label="Trading desk">
          <div class="rt-kicker">YOUR TYCOON</div><h3>Trading desk</h3><p data-shop>Run-down shop</p>
          <label for="rt-product" class="rt-label">Product</label><select id="rt-product" data-product></select>
          <p data-margin></p>
          <div class="rt-trade"><button class="rt-button rt-primary" data-buy>Buy $24</button><button class="rt-button" data-sell>Sell $37</button></div>
          <button class="rt-button rt-upgrade" data-upgrade>Upgrade · $180</button>
          <p data-renovation></p><p data-upgrade-note hidden>Keep $24 in cash or saleable stock for restocking.</p>
          <div class="rt-results" role="status" data-message>Buy your first item to start.</div>
          <div class="rt-mission"><div class="rt-kicker">NEXT MILESTONE</div><b data-mission>Make your first sale</b><p data-target>0 / 1 sold</p><progress data-progress aria-label="Milestone progress" max="1" value="0"></progress></div>
        </aside>
      </div>
      <dialog class="rt-settings" aria-labelledby="rt-settings-title"><div class="rt-settings-head"><h3 id="rt-settings-title">Settings</h3><button class="rt-button" data-done>Done</button></div>
        <fieldset><legend>Graphics</legend>
          <div class="rt-config">
            <div><label class="rt-label" for="rt-quality">Graphics preset</label><select id="rt-quality"><option>Low</option><option>Medium</option><option>High</option></select></div>
            <div><label class="rt-label" for="rt-distance">Render distance <output data-distance></output></label><input id="rt-distance" type="range" min="12" max="36"></div>
          </div>
          <label class="rt-toggle"><input id="rt-auto" type="checkbox"> Automatically lower resolution when needed</label>
          <div class="rt-config"><label class="rt-toggle"><input id="rt-shadows" type="checkbox"> Shadows</label><label class="rt-toggle"><input id="rt-fps" type="checkbox"> FPS counter</label></div>
        </fieldset>
        <fieldset><legend>Controls</legend>
          <label class="rt-label" for="rt-sensitivity">Camera sensitivity <output data-sensitivity></output></label>
          <input id="rt-sensitivity" type="range" min=".4" max="2" step=".1">
          <p class="rt-copy">WASD or arrows move relative to your view, E interacts, and Q/F turn. Drag the view to look around. Controller: left stick moves, right stick looks, A / Cross interacts. On touch, use the on-screen arrows and drag to look.</p>
        </fieldset>
        <fieldset><legend>Progress</legend>
          <p class="rt-copy" data-save-copy></p>
          <label class="rt-label" for="rt-code">Save code</label><textarea id="rt-code" rows="2" maxlength="110" placeholder="Create a code or paste one here" spellcheck="false"></textarea>
          <div class="rt-save-actions"><button class="rt-button" data-export>Get save code</button><button class="rt-button" data-import>Load code</button></div>
          <p class="rt-save-msg" role="status" data-save-msg></p>
        </fieldset>
      </dialog></div>`;
    const root=area.firstElementChild,$=s=>root.querySelector(s),canvas=$('canvas'),ctx=canvas.getContext('2d',{alpha:false,desynchronized:true});
    if(!ctx)throw new Error('Canvas unavailable');
    const view=$('.rt-view'),dialog=$('dialog'),fps=$('[data-fps]'),settingsBtn=$('[data-settings]'),product=$('[data-product]');
    const cash=$('[data-cash]'),stock=$('[data-stock]'),level=$('[data-level]'),shop=$('[data-shop]'),margin=$('[data-margin]');
    const buy=$('[data-buy]'),sell=$('[data-sell]'),upgrade=$('[data-upgrade]'),upgradeNote=$('[data-upgrade-note]'),message=$('[data-message]'),hint=$('[data-hint]');
    const mission=$('[data-mission]'),target=$('[data-target]'),progress=$('[data-progress]'),saveField=$('#rt-code'),saveMsg=$('[data-save-msg]');
    const distance=$('#rt-distance'),sensitivity=$('#rt-sensitivity'),quality=$('#rt-quality');
    const abort=new AbortController(),keys=new Set(),touches=new Map(),bufferedPresses=new Set();
    const on=(node,event,handler,options={})=>node.addEventListener(event,handler,{...options,signal:abort.signal});
    const player={x:savedPlayer.x,z:savedPlayer.z,walk:false};
    let yaw=savedPlayer.yaw,pitch=savedPlayer.pitch,home=savedPlayer.home||START,selected=0,near=null,dirty=true,closed=false,paused=false;
    let width=1,height=1,pixelRatio=1,extraScale=1,raf=0,last=0,lastDraw=0,drawDue=0,sampleStart=0,frames=0,opportunities=0,fast=0,slow=0;
    let drag=null,padDown=false,pad=null,nextPadCheck=0,padTimer=0,touchReleaseTimer=0,objects=0;
    const world=buildWorld();
    const marks=[];
    const facePool=[],faces=[],vertices=new Float64Array(24),floor=new Float64Array(12),scratch=new Float64Array(10),point=new Float64Array(3);
    const coarse=matchMedia('(pointer: coarse)').matches;
    let plotKey='',plotParts=[],plotWalls=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,customers=[makeCustomer(0),makeCustomer(1)];
    let customerTimer=0,customerTime=0,customerLast=0,visibleBubbles=0;
    const restingHint=coarse?'Use the arrows to move. Drag to look.':'WASD / arrows move · E interact · Drag to look';

    function upgradeFloor(tier){
      const stockValue=state.stock.reduce((sum,count,i)=>sum+count*STOCK[i].sell,0);
      return tier.cost+Math.max(0,STOCK[0].buy-stockValue);
    }
    function nextGoal(){
      if(!state.sold)return ['Make your first sale',state.sold,1,'sold'];
      if(state.level<2)return ['Open a corner shop',state.cash,upgradeFloor(LEVELS[0]),'wallet'];
      if(state.profit<300)return ['Earn $300 in profit',state.profit,300,'profit'];
      if(state.level<4)return ['Build your flagship',state.level,4,'tier'];
      if(state.profit<1600)return ['Earn $1,600 in profit',state.profit,1600,'profit'];
      return ['Market Row tycoon',state.profit,state.profit,'profit'];
    }
    function hud(rebuild=false){
      const tier=LEVELS[state.level-1],total=state.stock.reduce((a,b)=>a+b,0);
      if(rebuild){
        if(STOCK[selected].level>state.level)selected=0;
        product.replaceChildren(...STOCK.map((item,i)=>{
          const option=new Option(item.name+(item.level>state.level?` · Unlocks at Lv. ${item.level}`:''),i);
          option.disabled=item.level>state.level;return option;
        }));product.value=selected;
      }
      const item=STOCK[selected];
      cash.textContent=money(state.cash);stock.textContent=`${total} / ${tier.cap}`;level.textContent=`Level ${state.level}`;shop.textContent=tier.name;
      $('[data-renovation]').textContent=['Next: repair the roof and add a conveyor.','Next: add a showroom and display shelves.','Next: install flagship trim and a new sign.','Renovation complete.'][state.level-1];
      margin.textContent=`${state.stock[selected]} on hand · ${money(item.sell-item.buy)} profit each`;
      buy.textContent=`Buy ${money(item.buy)}`;buy.disabled=state.cash<item.buy||total>=tier.cap;
      sell.textContent=`Sell ${money(item.sell)}`;sell.disabled=!state.stock[selected];
      upgrade.textContent=tier.cost?`Upgrade · ${money(tier.cost)}`:'Flagship unlocked';upgrade.disabled=!tier.cost||state.cash<upgradeFloor(tier);
      upgradeNote.hidden=!tier.cost||state.cash<tier.cost||state.cash>=upgradeFloor(tier);
      const [name,value,max,unit]=nextGoal();
      mission.textContent=name;target.textContent=(unit==='profit'||unit==='wallet')?`${money(value)} / ${money(max)}`:`${value} / ${max} ${unit}`;
      progress.max=max;progress.value=value;
    }
    function transact(kind){
      const item=STOCK[selected],tier=LEVELS[state.level-1];
      if(kind==='buy'){
        if(buy.disabled){message.textContent=state.cash<item.buy?'Not enough cash.':'Stock is full. Sell or upgrade.';return}
        state.cash-=item.buy;state.stock[selected]++;message.textContent=`Bought 1 ${item.name.toLowerCase()}.`;
      }else if(kind==='sell'){
        if(sell.disabled){message.textContent='Buy this product before selling it.';return}
        state.cash+=item.sell;state.stock[selected]--;state.profit+=item.sell-item.buy;state.sold++;
        message.textContent=`Sold for ${money(item.sell)}. +${money(item.sell-item.buy)} profit.`;
      }else{
        if(upgrade.disabled){message.textContent=tier.cost?`You need ${money(upgradeFloor(tier))} to upgrade and keep trading.`:'Your shop is fully upgraded.';return}
        state.cash-=tier.cost;state.level++;
        message.textContent=`Plot upgraded! Capacity: ${LEVELS[state.level-1].cap}.`;
      }
      checkpoint();hud(kind==='upgrade');updateCustomers();dirty=true;schedule();
    }
    function syncHint(){
      hint.textContent=near?`At ${near.name.toLowerCase()} · ${coarse?'Tap Interact':'E / A to interact'}`:restingHint;
    }
    function nearest(){
      let candidate=null,closest=2.45**2;
      for(const station of STATIONS){
        const d=(player.x-station.x)**2+(player.z-station.foot)**2;
        if(d<closest){candidate=station;closest=d}
      }
      if(candidate!==near){near=candidate;syncHint();dirty=true}
    }
    function interact(){if(near)transact(near.kind);else message.textContent='Walk up to a lit stall or trade here.'}

    function fit(){
      const preset=PRESETS[settings.preset],w=Math.max(1,view.clientWidth),h=Math.max(1,view.clientHeight);
      pixelRatio=Math.max(.35,Math.min(preset.resolution*Math.min(devicePixelRatio||1,preset.dpr),Math.sqrt(preset.pixels/(w*h)))*extraScale);
      const pw=Math.max(1,Math.floor(w*pixelRatio)),ph=Math.max(1,Math.floor(h*pixelRatio));
      if(canvas.width!==pw||canvas.height!==ph){canvas.width=pw;canvas.height=ph;}
      width=w;height=h;dirty=true;
    }
    function ensurePlot(){
      const stockCount=state.stock[0]+state.stock[1]+state.stock[2],key=`${state.level}:${stockCount}`;
      if(key===plotKey)return;
      plotParts=buildPlot(state.level,stockCount);plotWalls=plotParts.filter(o=>o.solid);plotKey=key;
    }
    function nearShop(){return (player.x-PLOT.x)**2+(player.z-PLOT.z)**2<(Math.min(settings.distance,14)+1)**2}
    function updateCustomers(){
      for(const n of customers)sampleCustomer(n,customerTime,state.level);
    }
    function scheduleCustomers(){
      if(!active()||!nearShop()||customerTimer)return;
      customerLast=performance.now();
      customerTimer=setTimeout(customerTick,settings.preset==='Low'?67:50);
    }
    function customerTick(){
      customerTimer=0;
      if(!active()||!nearShop())return;
      const before=customerTime;
      customerTime+=Math.min(.22,(performance.now()-customerLast)*.001);
      updateCustomers();
      const c=Math.cos(yaw),s=Math.sin(yaw);
      for(const n of customers){
        if(!n.changed)continue;
        const dx=n.x-player.x,dz=n.z-player.z;
        if(dx*s-dz*c>-1.4&&Math.abs(dx*c+dz*s)<Math.max(6,(dx*s-dz*c)*1.5)){
          dirty=true;if(!raf)render();break;
        }
      }
      if(customerTime>before)scheduleCustomers();
    }
    function blockedBubble(x,y,z){
      for(const o of plotWalls){
        let lo=.025,hi=.98;
        for(let axis=0;axis<3;axis++){
          const from=axis===0?player.x:axis===1?EYE:player.z,to=axis===0?x:axis===1?y:z;
          const min=axis===0?o.x-o.w*.5:axis===1?o.y:o.z-o.d*.5;
          const max=axis===0?o.x+o.w*.5:axis===1?o.y+o.h:o.z+o.d*.5;
          const d=to-from;
          if(Math.abs(d)<.0001){if(from<min||from>max){hi=-1;break}continue}
          const a=(min-from)/d,b=(max-from)/d;
          lo=Math.max(lo,Math.min(a,b));hi=Math.min(hi,Math.max(a,b));
          if(lo>hi)break;
        }
        if(lo<=hi)return true;
      }
      return false;
    }
    function render(){
      ctx.setTransform(pixelRatio,0,0,pixelRatio,0,0);
      const c=Math.cos(yaw),s=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
      const midX=width*.5,midY=height*.5,focal=Math.min(width*.45,height*.95);
      const hSlope=midX/focal,vSlope=midY/focal,hSlack=Math.hypot(1,hSlope),vSlack=Math.hypot(1,vSlope);
      function camera(out,i,x,y,z){
        const dx=x-player.x,dz=z-player.z,dy=y-EYE,forward=dx*s-dz*c;
        out[i]=dx*c+dz*s;out[i+1]=dy*cp-forward*sp;out[i+2]=forward*cp+dy*sp;
      }
      function project(x,y,z){
        camera(point,0,x,y,z);
        if(point[2]<CLIP)return false;
        const scale=focal/point[2];
        point[0]=midX+point[0]*scale;point[1]=midY-point[1]*scale;return true;
      }
      // Clip each quad before perspective division so nearby surfaces stay stable
      // as they pass through the eye plane. The scratch space holds at most 5 points.
      function clip(source,a,b,d,e){
        let count=0;
        for(let i=0,prev=e;i<4;i++){
          const cur=i===0?a:i===1?b:i===2?d:e,z=source[cur+2],pz=source[prev+2];
          if((z>=CLIP)!==(pz>=CLIP)){
            const t=(CLIP-pz)/(z-pz),scale=focal/CLIP;
            scratch[count++]=midX+(source[prev]+(source[cur]-source[prev])*t)*scale;
            scratch[count++]=midY-(source[prev+1]+(source[cur+1]-source[prev+1])*t)*scale;
          }
          if(z>=CLIP){
            const scale=focal/z;
            scratch[count++]=midX+source[cur]*scale;scratch[count++]=midY-source[cur+1]*scale;
          }
          prev=cur;
        }
        return count;
      }
      function path(points,count,fill){
        ctx.fillStyle=fill;ctx.beginPath();ctx.moveTo(points[0],points[1]);
        for(let i=2;i<count;i+=2)ctx.lineTo(points[i],points[i+1]);
        ctx.closePath();ctx.fill();
      }
      function ground(x1,z1,x2,z2,y,color){
        if(y>=EYE)return;
        camera(floor,0,x1,y,z1);camera(floor,3,x2,y,z1);camera(floor,6,x2,y,z2);camera(floor,9,x1,y,z2);
        const n=clip(floor,0,3,6,9);
        if(n>=6)path(scratch,n,color);
      }
      ctx.fillStyle='#75c9ef';ctx.fillRect(0,0,width+1,height+1);
      ground(-25,-22,25,22,-1.4,'#4baee2');
      ground(-22,-19,22,19,-.65,'#3c794f');
      ground(-21.5,-18.5,21.5,18.5,0,'#7abd57');
      ground(-17,-8.2,17,3.6,.02,'#a6b0ac');
      ground(-17,-1.45,17,2.65,.025,'#c9d4d0');
      ground(-1.6,2.4,1.6,18.5,.027,'#bbc9c4');
      ground(-10.7,2.7,-2.5,3.7,.038,'#d9e3db');
      ground(-10.7,3.65,-2.5,10.85,.04,'#477d43');
      ground(-10.36,3.88,-2.82,10.55,.045,'#d4dfcb');
      // Draw the broad plot slab before sorting the furniture so it can never
      // cover a small prop that happens to have a shallower center depth.
      ground(PLOT.x-3.675,PLOT.z-3.125,PLOT.x+3.675,PLOT.z+3.35,.05,'#a0ac8a');
      ground(PLOT.x-3.675,PLOT.z-3.125,PLOT.x+3.675,PLOT.z+3.125,.19,state.level===1?'#a3997b':'#e5ddc8');
      ground(PLOT.x-1.33,PLOT.z-3.82,PLOT.x+1.33,PLOT.z-3.10,.075,state.level===1?'#aaa18a':'#cdc7b6');
      if(state.level===1){
        ground(PLOT.x+.55,PLOT.z-2.38,PLOT.x+1.44,PLOT.z-1.9,.195,'#7c7460');
        ground(PLOT.x-1.22,PLOT.z+.88,PLOT.x-.46,PLOT.z+1.45,.195,'#89846a');
      }else ground(PLOT.x-1.22,PLOT.z-2.88,PLOT.x+1.22,PLOT.z-2.13,.195,state.level===4?'#6249a2':'#4b957e');
      const studStep=PRESETS[settings.preset].detail?2:3.5;
      ctx.fillStyle='#52765d45';ctx.beginPath();
      for(let x=-15.75;x<=16;x+=studStep)for(let z=-7;z<=1.8;z+=studStep*.78){
        if(!project(x,.04,z))continue;
        const sx=point[0],sy=point[1],scale=Math.min(focal/point[2],60);
        if(sx>=0&&sx<=width&&sy>=0&&sy<=height)ctx.rect(sx-scale*.085,sy-scale*.043,scale*.17,scale*.086);
      }
      ctx.fill();
      for(const station of STATIONS){
        const {x,foot,color}=station;
        ground(x-2.65,foot-1.45,x+2.65,foot+1.3,.055,'#617f78');
        ground(x-1.20,foot-.65,x+1.20,foot+.64,.07,'#345653');
        ground(x-1.11,foot-.65,x+1.11,foot+.48,.08,color);
        ground(x-.84,foot-.43,x+.84,foot+.28,.09,station===near?'#f5fff4':station.roof);
        ground(x-.27,foot-.15,x+.27,foot+.04,.10,station===near?station.side:'#fff7d1');
      }
      const all=world.near(player.x,player.z,settings.distance,PRESETS[settings.preset].detail);
      ensurePlot();
      const showPlot=(player.x-PLOT.x)**2+(player.z-PLOT.z)**2<(settings.distance+3)**2;
      if(settings.shadows){
        for(const o of all)if(o.shadow)ground(o.x-o.w*.47+.42,o.z-o.d*.45+.28,o.x+o.w*.56+.42,o.z+o.d*.55+.28,.044,'#21464655');
      }
      faces.length=0;objects=0;
      function addFace(a,b,d,e,col){
        const n=clip(vertices,a,b,d,e);if(n<6)return;
        const i=faces.length,f=facePool[i]||(facePool[i]={xy:new Float64Array(10),depth:0,col:'',count:0});
        for(let j=0;j<n;j++)f.xy[j]=scratch[j];
        f.count=n;
        f.depth=(vertices[a+2]+vertices[b+2]+vertices[d+2]+vertices[e+2])*.25;f.col=col;faces.push(f);
      }
      function mesh(o){
        const wx=o.w*.5,wz=o.d*.5,top=o.y+o.h,bound=(o.w+o.d+o.h)*.5;
        camera(point,0,o.x,o.y+o.h*.5,o.z);
        const depth=point[2];
        if(depth+bound<CLIP||Math.abs(point[0])-hSlope*depth>bound*hSlack||Math.abs(point[1])-vSlope*depth>bound*vSlack)return;
        objects++;
        for(let i=0;i<4;i++){
          const x=o.x+(i===0||i===3?-wx:wx),z=o.z+(i<2?-wz:wz),j=i*3;
          camera(vertices,j,x,o.y,z);
          vertices[j+12]=vertices[j];vertices[j+13]=vertices[j+1]+o.h*cp;vertices[j+14]=vertices[j+2]+o.h*sp;
        }
        if(player.x>o.x+wx)addFace(3,6,18,15,o.side);
        else if(player.x<o.x-wx)addFace(9,0,12,21,o.side);
        if(player.z>o.z+wz)addFace(6,9,21,18,o.front);
        else if(player.z<o.z-wz)addFace(0,3,15,12,o.front);
        if(EYE>top)addFace(12,15,18,21,o.top);
        else if(EYE<o.y)addFace(0,3,6,9,o.side);
      }
      for(const o of all)mesh(o);
      if(showPlot)for(const o of plotParts)mesh(o);
      if(showPlot)for(const n of customers){
        if(n.visible){
          poseCustomer(n,reduced);
          for(const part of n.parts)mesh(part);
        }
      }
      faces.sort(byDepth);
      for(const f of faces)path(f.xy,f.count,f.col);
      marks.length=0;
      const fontSize=width<440?11:12;
      ctx.font=`800 ${fontSize}px system-ui,sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';
      const caption=(name,color,x,y)=>{
        const w=ctx.measureText(name).width+16;
        if(x-w/2<0||y<10||x+w/2>width||y>height-12)return 0;
        ctx.fillStyle='#163a41';ctx.beginPath();ctx.roundRect(x-w/2,y-10,w,20,5);ctx.fill();
        ctx.fillStyle=color;ctx.fillText(name,x,y+.4);return w;
      };
      for(const station of STATIONS){
        if((station.x-player.x)**2+(station.z-player.z)**2>settings.distance**2)continue;
        let x=Infinity,y=Infinity,w=0,px=Infinity,py=Infinity;
        if(project(station.x,3.55,station.z)){x=point[0];y=point[1];w=caption(station.name,station.color,x,y)}
        if(project(station.x,.09,station.foot)){px=point[0];py=point[1]}
        marks.push({station,x,y,w,px,py});
      }
      if(showPlot&&player.z<PLOT.z-3.25&&project(PLOT.x,state.level===4?3.71:3.22,PLOT.z-3.35)){
        caption(`${LEVELS[state.level-1].sign}  ·  LV ${state.level}`,state.level===1?'#f8dbaa':'#ffed9e',point[0],point[1]);
      }
      let bubbleLeft=Infinity,bubbleRight=-Infinity,bubbleY=-Infinity,bubbleCount=0;
      if(showPlot)for(const n of customers){
        if(!n.visible||!n.line||!project(n.x,n.y+1.79,n.z))continue;
        const ax=point[0],ay=point[1],depth=point[2];
        if(depth>.95&&ax>=6&&ax<=width-6&&ay>45&&ay<height-3&&!blockedBubble(n.x,n.y+1.62,n.z)){
          const w=ctx.measureText(n.line).width+22,left=clamp(ax-w/2,6,width-w-6),y=ay-25;
          if(left<bubbleRight+5&&left+w>bubbleLeft-5&&Math.abs(y-bubbleY)<26)continue;
          ctx.fillStyle='#fff8e5';ctx.strokeStyle='#263541';ctx.lineWidth=1.5;
          ctx.beginPath();ctx.roundRect(left,y,w,24,7);ctx.fill();ctx.stroke();
          const hook=clamp(ax,left+7,left+w-7);
          ctx.beginPath();ctx.moveTo(hook-4,y+23);ctx.lineTo(hook+4,y+23);ctx.lineTo(ax,y+30);ctx.closePath();ctx.fill();
          ctx.fillStyle='#213341';ctx.fillText(n.line,left+w/2,y+12);
          bubbleLeft=left;bubbleRight=left+w;bubbleY=y;bubbleCount++;
        }
      }
      visibleBubbles=bubbleCount;
      ctx.beginPath();ctx.moveTo(midX-6,midY);ctx.lineTo(midX+6,midY);ctx.moveTo(midX,midY-6);ctx.lineTo(midX,midY+6);
      ctx.lineWidth=3.6;ctx.strokeStyle='#17333dcc';ctx.stroke();
      ctx.lineWidth=1.5;ctx.strokeStyle='#fff9e0';ctx.stroke();
      dirty=false;
      scheduleCustomers();
    }
    function byDepth(a,b){return b.depth-a.depth}
    function syncSettings(){
      const preset=PRESETS[settings.preset];
      quality.value=settings.preset;distance.value=settings.distance;sensitivity.value=settings.sensitivity;
      $('#rt-shadows').checked=settings.shadows;$('#rt-fps').checked=settings.fps;$('#rt-auto').checked=settings.auto;
      $('[data-distance]').textContent=`· ${settings.distance}`;$('[data-sensitivity]').textContent=`· ${settings.sensitivity.toFixed(1)}×`;
      fps.hidden=!settings.fps;
      fps.title=`${settings.preset} preset, up to ${Math.round(preset.pixels/1000)}K render pixels`;
    }
    function setSetting(){
      syncSettings();fit();
      if(!document.hidden)render();
    }
    function clearInput(){
      keys.clear();touches.clear();bufferedPresses.clear();drag=null;padDown=false;
      clearTimeout(touchReleaseTimer);touchReleaseTimer=0;
    }
    function resetTiming(){last=0;lastDraw=0;drawDue=0;sampleStart=0;frames=0;opportunities=0;fast=0;slow=0}
    function active(){return !closed&&!paused&&!document.hidden}
    function halt(){
      if(raf)cancelAnimationFrame(raf);
      raf=0;clearTimeout(padTimer);padTimer=0;clearTimeout(customerTimer);customerTimer=0;resetTiming();player.walk=false;clearInput();
      if(!fps.hidden)fps.textContent=paused?'FPS · paused':'FPS · idle';
    }
    function schedule(){
      if(!active()||raf)return;
      clearTimeout(padTimer);padTimer=0;
      raf=requestAnimationFrame(frame);
    }
    function pollForController(){
      if(!active()||raf||padTimer||typeof navigator.getGamepads!=='function')return;
      // Discovery stays out of requestAnimationFrame while the scene is asleep.
      padTimer=setTimeout(()=>{
        padTimer=0;
        if(!active())return;
        if(controller(performance.now()))schedule();
        else pollForController();
      },Math.max(100,Math.ceil(nextPadCheck-performance.now()+4)));
    }
    function axis(v=0){const a=Math.abs(v);return a<.17?0:Math.sign(v)*(a-.17)/.83}
    function controller(t){
      if(!pad&&t<nextPadCheck)return null;
      try{
        const devices=navigator.getGamepads?.()||[];
        const current=pad?devices[pad.index]:null;
        pad=current?.connected?current:null;
        if(!pad)for(const device of devices)if(device?.connected){pad=device;break}
      }catch{pad=null}
      if(!pad)nextPadCheck=t+800;
      return pad;
    }
    function update(dt,t){
      const gp=controller(t);
      const pressed=key=>keys.has(key)||bufferedPresses.has(key);
      let dx=Number(pressed('right'))-Number(pressed('left'))+axis(gp?.axes[0]);
      let dz=Number(pressed('down'))-Number(pressed('up'))+axis(gp?.axes[1]);
      for(const touch of touches.values()){
        if(pressed(touch))continue;
        if(touch==='right')dx++;else if(touch==='left')dx--;
        else if(touch==='down')dz++;else if(touch==='up')dz--;
      }
      const rotate=Number(pressed('rotR'))-Number(pressed('rotL'))+axis(gp?.axes[2]),tilt=axis(gp?.axes[3]);
      bufferedPresses.clear();
      if(rotate||tilt)turn(rotate*dt*1.85,tilt*dt*1.35);
      const length=Math.hypot(dx,dz),wasWalking=player.walk;
      player.walk=length>.01;
      if(player.walk){
        if(length>1){dx/=length;dz/=length}
        const c=Math.cos(yaw),s=Math.sin(yaw),vx=dx*c-dz*s,vz=dz*c+dx*s;
        const step=dt*7.8;
        const x=clamp(player.x+vx*step,-20,20),z=clamp(player.z+vz*step,-16,17);
        ensurePlot();
        const blocked=(a,b)=>STATIONS.some(station=>Math.abs(a-station.x)<2.68&&Math.abs(b-station.z)<1.64)||
          plotWalls.some(o=>o.y<EYE&&Math.abs(a-o.x)<o.w*.5+.22&&Math.abs(b-o.z)<o.d*.5+.22);
        if(!blocked(x,player.z))player.x=x;
        if(!blocked(player.x,z))player.z=z;
        dirty=true;
      }
      if(wasWalking!==player.walk)dirty=true;
      nearest();
      const action=Boolean(gp?.buttons[0]?.pressed);
      if(action&&!padDown)interact();
      padDown=action;
    }
    function frame(t){
      raf=0;
      if(!active())return;
      const dt=last?Math.min((t-last)*.001,.05):1/60;
      last=t;if(!sampleStart)sampleStart=t;opportunities++;
      update(dt,t);
      if(dirty&&(!drawDue||t>=drawDue-1.2)){
        render();lastDraw=t;frames++;
        drawDue=drawDue&&t-drawDue<50?Math.max(drawDue+1000/60,t+4):t+1000/60;
      }
      const elapsed=t-sampleStart;
      if(elapsed>=750){
        const rate=Math.round(frames*1000/elapsed),active=t-lastDraw<220,steady=frames>=opportunities*.43&&frames>8&&active;
        if(!fps.hidden)fps.textContent=steady?`${rate} FPS · ${settings.preset}`:`FPS · ${active?'ready':'idle'}`;
        if(settings.auto&&steady){
          if(rate<47){slow++;fast=0}else if(rate>=56){fast++;slow=0}else{fast=0;slow=0}
          if(slow>=2&&extraScale>.62){extraScale=Math.max(.62,extraScale-.16);slow=0;fit()}
          if(fast>=6&&extraScale<1){extraScale=Math.min(1,extraScale+.08);fast=0;fit()}
        }else{slow=0;fast=0}
        frames=0;opportunities=0;sampleStart=t;
      }
      if(dirty||player.walk||keys.size||touches.size||pad){schedule();return}
      resetTiming();
      if(!fps.hidden&&fps.textContent!=='FPS · idle')fps.textContent='FPS · idle';
      pollForController();
    }
    function turn(right,down){
      yaw=(yaw+right*settings.sensitivity)%(2*Math.PI);
      pitch=clamp(pitch-down*settings.sensitivity,-1.40,1.40);dirty=true;
    }
    function recenter(){yaw=home.yaw;pitch=home.pitch;dirty=true;canvas.focus({preventScroll:true});schedule()}
    function visit(place){clearInput();home=place;player.x=place.x;player.z=place.z;nearest();recenter()}
    function openSettings(){
      paused=true;halt();syncSettings();saveMsg.textContent='';
      $('[data-save-copy]').textContent=addressSave
        ?'This page updates your save link as you play. Reload this same link to resume, or keep a save code.'
        :'Progress is kept when you return to the arcade. To resume after refreshing or on another device, keep a save code.';
      dialog.showModal();
    }
    on(dialog,'close',()=>{paused=false;clearInput();dirty=true;if(!fps.hidden)fps.textContent='FPS · ready';settingsBtn.focus();schedule()});
    on(settingsBtn,'click',openSettings);on($('[data-done]'),'click',()=>dialog.close());
    on(quality,'change',()=>{
      settings.preset=quality.value;const p=PRESETS[settings.preset];settings.distance=p.distance;settings.shadows=p.shadows;extraScale=1;setSetting();
    });
    on(distance,'input',()=>{settings.distance=Number(distance.value);setSetting()});
    on(sensitivity,'input',()=>{settings.sensitivity=Number(sensitivity.value);syncSettings()});
    on($('#rt-shadows'),'change',e=>{settings.shadows=e.target.checked;setSetting()});
    on($('#rt-fps'),'change',e=>{settings.fps=e.target.checked;syncSettings()});
    on($('#rt-auto'),'change',e=>{settings.auto=e.target.checked;extraScale=1;setSetting()});
    on($('[data-export]'),'click',()=>{
      saveField.value=saveCode();saveField.focus();saveField.select();saveMsg.textContent='Code selected. Copy it somewhere safe.';
    });
    on($('[data-import]'),'click',()=>{
      const restored=readCode(saveField.value);
      if(!restored){saveMsg.textContent='That code isn’t valid. Current progress was kept.';return}
      state=restored;checkpoint();hud(true);updateCustomers();dirty=true;saveMsg.textContent='Progress restored.';message.textContent='Save restored.';
    });
    on(product,'change',()=>{selected=Number(product.value);hud()});
    on(buy,'click',()=>transact('buy'));on(sell,'click',()=>transact('sell'));on(upgrade,'click',()=>transact('upgrade'));
    on($('[data-center]'),'click',recenter);on($('[data-interact]'),'click',interact);
    on($('[data-shop-view]'),'click',()=>visit(START));on($('[data-market-view]'),'click',()=>visit(MARKET));
    on(window,'blur',clearInput);
    on(window,'gamepadconnected',()=>{nextPadCheck=0;schedule()});
    on(window,'gamepaddisconnected',()=>{nextPadCheck=0;schedule()});
    on(document,'visibilitychange',()=>{if(document.hidden)halt();else{dirty=true;schedule()}});
    function mapped(key){return keyDir[key]||(key==='q'?'rotL':key==='f'?'rotR':null)}
    on(document,'keydown',e=>{
      if(paused||e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey||/^(SELECT|INPUT|TEXTAREA)$/.test(e.target.tagName))return;
      const key=e.key.toLowerCase(),dir=mapped(key);
      if(dir){if(!keys.has(dir))bufferedPresses.add(dir);keys.add(dir);e.preventDefault();schedule()}
      if(key==='e'&&!e.repeat){e.preventDefault();interact()}
    });
    on(document,'keyup',e=>{const dir=mapped(e.key.toLowerCase());if(dir&&keys.delete(dir))schedule()});
    for(const btn of root.querySelectorAll('[data-dir]')){
      on(btn,'pointerdown',e=>{touches.set(e.pointerId,btn.dataset.dir);bufferedPresses.add(btn.dataset.dir);btn.setPointerCapture(e.pointerId);schedule()});
      for(const event of ['pointerup','pointercancel','lostpointercapture'])on(btn,event,e=>{if(touches.delete(e.pointerId))schedule()});
      on(btn,'click',e=>{
        if(e.detail!==0)return;
        touches.set(-1,btn.dataset.dir);schedule();clearTimeout(touchReleaseTimer);
        touchReleaseTimer=setTimeout(()=>{touchReleaseTimer=0;if(touches.delete(-1))schedule()},85);
      });
    }
    on(canvas,'pointerdown',e=>{
      if(e.button!==0||drag)return;
      drag={id:e.pointerId,x:e.clientX,y:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId);
    });
    on(canvas,'pointermove',e=>{
      if(!drag||drag.id!==e.pointerId)return;
      if(!drag.moved&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<5)return;
      drag.moved=true;turn((e.clientX-drag.x)*.006,(e.clientY-drag.y)*.006);
      drag.x=e.clientX;drag.y=e.clientY;schedule();
    });
    on(canvas,'pointerup',e=>{
      if(!drag||drag.id!==e.pointerId)return;
      if(!drag.moved){
        const bounds=canvas.getBoundingClientRect(),x=e.clientX-bounds.left,y=e.clientY-bounds.top;
        const hit=marks.find(m=>(m.w&&Math.abs(x-m.x)<m.w/2+3&&Math.abs(y-m.y)<13)||(Math.abs(x-m.px)<17&&Math.abs(y-m.py)<11));
        if(hit){if(near===hit.station)transact(near.kind);else message.textContent=`Walk up to ${hit.station.name.toLowerCase()}, or use the trading desk.`}
      }
      drag=null;
    });
    for(const event of ['pointercancel','lostpointercapture'])on(canvas,event,()=>{drag=null});
    const observer=new ResizeObserver(()=>{fit();if(paused&&!document.hidden)render();else schedule()});observer.observe(view);
    fit();nearest();if(!near)hint.textContent=restingHint;hud(true);syncSettings();updateCustomers();render();canvas.focus({preventScroll:true});schedule();

    window.render_game_to_text=()=>JSON.stringify({
      mode:paused?'settings':document.hidden?'hidden':'playing',player:{x:player.x,z:player.z},view:'first-person',yaw,pitch,near:near?.kind??null,
      stations:STATIONS.map(({x,foot,kind})=>({x,z:foot,kind})),...state,product:selected,
      plot:{...PLOT,level:state.level,name:LEVELS[state.level-1].name,parts:plotParts.length},
      customers:customers.filter(n=>n.visible).map(({x,z,phase,line})=>({x,z,phase,line})),visibleBubbles,
      graphics:{...settings,width:canvas.width,height:canvas.height,objects,scale:extraScale},rendering:!!raf
    });
    window.advanceTime=ms=>{
      if(paused||closed||document.hidden)return;
      for(let i=0;i<Math.min(600,Math.max(1,Math.round(ms/(1000/60))));i++)update(1/60,performance.now());
      if(nearShop()){customerTime+=Math.min(10,Math.max(0,ms*.001));updateCustomers();dirty=true}
      if(dirty)render();
    };
    return ()=>{
      closed=true;savedPlayer={x:player.x,z:player.z,yaw,pitch,home};halt();observer.disconnect();abort.abort();
      delete window.render_game_to_text;delete window.advanceTime;
    };
  }

  function box(x,y,z,w,h,d,top,front,side,shadow=false,detail=0){return {x,y,z,w,h,d,top,front,side,shadow,detail}}
  function buildWorld(){
    const chunks=new Map(),size=8;
    const register=(x,z,build)=>{
      const ix=Math.floor(x/size),iz=Math.floor(z/size),key=`${ix}:${iz}`;
      if(!chunks.has(key))chunks.set(key,{x,z,ix,iz,makers:[],data:null});
      chunks.get(key).makers.push(build);
    };
    for(const st of STATIONS)register(st.x,st.z,()=>{
      const {x,z,color,roof,side,wall}=st;
      const list=[
        box(x,0,z,5.1,.22,3.4,'#8492a0','#4c5e75','#40546d',true),
        box(x,.22,z-.7,4.75,2.55,1.82,wall,wall,side),
        box(x,.23,z+1.02,4.58,.87,.85,wall,side,'#30465d'),
        box(x,1.1,z+1.04,4.65,.12,.93,'#d8ad83','#ab846a','#7a6b65'),
        box(x,2.72,z,5.12,.23,3.15,roof,wall,side)
      ];
      for(const d of [-2.23,2.23])list.push(box(x+d,.23,z+1.3,.16,2.52,.18,'#dec5a4','#b18e6c','#866b60'));
      for(let i=0;i<7;i++)list.push(box(x+(i-3)*.71,2.47,z+1.6,.69,.27,.75,i%2?color:roof,i%2?color:roof,side));
      for(let i=0;i<3;i++)list.push(box(x+(i-1)*.96,1.22,z+.93,.61,.35+(.07*i),.58,i%2?color:'#e8bb88',i%2?side:'#b28461',wall));
      list.push(box(x,2.93,z-.38,2.7,.32,.26,color,'#34475f',side,false,1));
      return list;
    });
    const buildings=[
      [-14,-13,4.2,2.8,'#b7d781','#71a964'],[-7,-15,4.9,4.5,'#a6d476','#65a460'],[-1,-15,4.6,2.9,'#bedf88','#81ad67'],
      [5,-16,4.4,4.7,'#b6d985','#70a263'],[11,-13,4.3,3.7,'#bfdd8b','#86b16b'],[16,-11,3.9,3.0,'#b3d588','#72a467'],
      [-18,-3,3.2,1.45,'#9acb6d','#699653'],[18,.8,3.2,1.5,'#a9d875','#78aa61']
    ];
    for(const [x,z,w,h,top,side] of buildings)register(x,z,()=>{
      return [box(x,0,z,w,h,3.2,top,side,'#678a55',true),box(x,h*.65,z,w*.72,h*.44,2.65,top,side,'#698f55',false,1)];
    });
    let random=92453;
    const rand=()=>((random=Math.imul(random,1664525)+1013904223>>>0)/4294967296);
    for(let i=0;i<30;i++){
      const side=i%2?-1:1,x=side*(9+rand()*10),z=-6+rand()*22,h=1.3+rand()*1.2,detail=i%4===0?0:i%3===0?1:2;
      register(x,z,()=>[
        box(x,0,z,.34,h,.34,'#a48159','#84633d','#725435',false,detail),
        box(x,h*.6,z,1.46,1.24,1.43,'#92d76b','#4caa59','#428d51',true,detail),
        box(x-.24,h*.6+.91,z+.05,.97,.54,.97,'#b3e57a','#76bb60','#5b9a54',false,detail)
      ]);
    }
    for(const [x,z] of [[-11,3.8],[4,6],[11,3.5],[-13,-2],[13,-2],[-5,-9],[5,-9],[8,11]])register(x,z,()=>[
      box(x,0,z,.2,2.78,.2,'#9aaab7','#536980','#32465e',true),
      box(x,2.74,z,.56,.32,.54,'#fff1bc','#e9c88e','#bc9b70'),
      box(x,3.06,z,.62,.12,.59,'#8799a6','#415a71','#354c69')
    ]);
    for(const [x,z] of [[-9,1],[9,1],[8,8],[-13,-3],[13,-3]])register(x,z,()=>[
      box(x,0,z,1,.64,.95,'#e1b581','#ba8a60','#916745',true),
      box(x+.45,0,z+.72,.75,.41,.65,'#d8a879','#a87855','#80593d',false,1)
    ]);
    let lastX=Infinity,lastZ=Infinity,lastDist=0,lastDetail=-1,visible=[];
    return {near(x,z,r,detail){
      if((x-lastX)**2+(z-lastZ)**2<.8&&r===lastDist&&detail===lastDetail)return visible;
      lastX=x;lastZ=z;lastDist=r;lastDetail=detail;visible=[];
      const r2=r*r;
      for(const chunk of chunks.values()){
        const dx=Math.max(chunk.ix*size-x,0,x-(chunk.ix+1)*size),dz=Math.max(chunk.iz*size-z,0,z-(chunk.iz+1)*size);
        if(dx*dx+dz*dz>r2)continue;
        if(!chunk.data)chunk.data=chunk.makers.flatMap(make=>make());
        for(const o of chunk.data)if(o.detail<=detail&&(o.x-x)**2+(o.z-z)**2<r2)visible.push(o);
      }
      return visible;
    }};
  }
  function makeCustomer(id){
    const skin=id?['#c99065','#ab714d','#8c583e']:['#ffd4a1','#edb480','#cc8e68'];
    const shirt=id?['#eeaaf9','#ab62be','#874b9f']:['#8cf2d5','#32aa93','#277768'];
    const pants=['#7194c5','#465f99','#364b7e'],hair=['#624d38','#483526','#362b22'],eyes=['#312a36','#312a36','#312a36'];
    const part=(offset,y,w,h,d,palette)=>Object.assign(box(0,y,0,w,h,d,...palette),{offset,base:y});
    return {id,x:PLOT.x,z:PLOT.z,y:0,phase:'away',line:'',visible:false,changed:false,walking:false,facing:1,age:0,
      parts:[part(-.155,0,.27,.49,.32,pants),part(.155,0,.27,.49,.32,pants),part(0,.48,.56,.59,.36,shirt),
        part(-.37,.48,.19,.56,.28,shirt),part(.37,.48,.19,.56,.28,shirt),part(0,1.06,.48,.44,.43,skin),
        part(0,1.48,.52,.14,.46,hair),part(-.105,1.29,.045,.075,.025,eyes),part(.105,1.29,.045,.075,.025,eyes)]};
  }
  function sampleCustomer(n,time,tier){
    const elapsed=time-n.id*6.8,cycle=Math.floor(elapsed/23),t=elapsed-cycle*23;
    const prev=n.visible,oldX=n.x,oldZ=n.z,oldLine=n.line,side=n.id?-.48:.48;
    n.visible=elapsed>=0&&t<15.6;
    if(!n.visible){n.changed=prev;n.phase='away';n.line='';return}
    const door=-2.72,sidewalk=-4.95,browse=n.id?.52:-.75;
    let x=side,z=sidewalk,slot=0;
    n.facing=1;n.walking=true;n.phase='entering';n.age=t;
    if(t<1.35){x=side+(n.id?3.1:0)*(1-t/1.35);z=sidewalk+(.35*t/1.35)}
    else if(t<4){z=sidewalk+.35+(door-sidewalk-.35)*(t-1.35)/2.65}
    else if(t<6.1){z=door+(browse-door)*(t-4)/2.1}
    else if(t<11.35){z=browse;n.walking=false;n.facing=-1;n.phase='browsing';slot=t<8.85?1:2}
    else{z=browse+(sidewalk-browse)*(t-11.35)/4.25;n.facing=-1;n.phase='leaving';slot=2}
    n.x=PLOT.x+x;n.z=PLOT.z+z;n.y=z>-3.04?.19:.025;
    n.line=t>13.85?'':CUSTOMER_LINES[tier-1][(slot+cycle+n.id)%3];
    n.changed=!prev||n.x!==oldX||n.z!==oldZ||n.line!==oldLine;
  }
  function poseCustomer(n,reduced){
    const stride=n.walking&&!reduced?Math.sin(n.age*10)*.105:0;
    for(let i=0;i<n.parts.length;i++){
      const p=n.parts[i];p.x=n.x+p.offset;p.y=n.y+p.base;
      p.z=n.z+(i<2?stride*(i===0?1:-1):i===3?-stride:i===4?stride:i>=7?n.facing*.218:0);
    }
  }
  function buildPlot(tier,stock){
    const parts=[],{x,z}=PLOT;
    const make=(dx,y,dz,w,h,d,palette,solid=false)=>parts.push({...box(x+dx,y,z+dz,w,h,d,...palette),solid});
    const trim=[['#84776b','#685c52','#554c45'],['#a0d8bb','#4e9d82','#397964'],
      ['#b8eaff','#6ba9ca','#4882ab'],['#ddc5ff','#8663c4','#604695']][tier-1];
    const wall=[['#a88d73','#907563','#746458'],['#dfcca8','#beab87','#a29575'],
      ['#d3e9ee','#9abac7','#648e9f'],['#f2ece1','#c4bde4','#a69ac7']][tier-1];
    const roof=[['#81665e','#624e4e','#594747'],['#67978c','#396f68','#356258'],
      ['#5a94b4','#326987','#2b5a76'],['#8c73bc','#5f438a','#4d3a75']][tier-1];
    const wood=['#b99867','#9d7857','#775e48'],metal=['#8ba3a4','#677e86','#4f6873'];
    const gold=['#ffe49c','#cda75d','#a47c45'],teal=['#63e2c5','#389e94','#2d776f'];
    const high=tier===4?3.68:3.2;
    make(0,.19,2.88,7.15,high-.19,.28,wall,true);
    for(const side of [-1,1]){
      make(side*3.43,.19,0,.27,high-.19,5.8,wall,true);
      make(side*2.43,.19,-2.97,2.03,.82,.29,wall,true);
      make(side*2.43,2.15,-2.97,2.01,high-2.15,.29,wall,true);
      make(side*1.43,.19,-2.98,.24,high-.19,.34,trim,true);
      make(side*3.36,.19,-2.98,.28,high-.19,.36,trim,true);
      make(side*2.39,.94,-3.02,1.78,.13,.42,trim);
      if(tier===1){
        make(side*2.36,1.21,-3.16,1.61,.23,.09,wood,true);
        make(side*2.43,1.69,-3.14,1.56,.24,.09,['#bdaa85','#967e64','#816751'],true);
        make(side*2.75,1.03,-3.22,.19,1.14,.10,wood,true);
        make(side*2.91,.24,-3.15,.58,.19,.07,['#998278','#80695f','#6e5750']);
      }else{
        make(side*2.38,1.56,-2.98,.09,1.18,.32,trim,true);
        make(side*2.37,1.9,-3.01,1.64,.08,.22,trim);
      }
    }
    make(0,2.45,-2.97,2.87,high-2.45,.35,trim,true);
    if(tier===1){
      make(-2.08,high,-.06,2.67,.24,6.13,roof,true);
      make(1.99,high,-.35,2.54,.24,5.63,roof,true);
      make(.03,high-.09,1.86,2.02,.29,2.22,roof,true);
      make(-.63,high-.1,-2.52,.43,.24,1.18,wood);
      make(.57,high-.1,-2.27,.27,.24,1.42,wood);
      make(0,3.04,-3.18,3.78,.34,.23,wood);
      make(-3.01,.08,-3.59,.63,.52,.57,metal);
      make(3.02,.09,-3.56,.65,.53,.59,wood);
      make(2.75,.09,-3.88,.6,.14,.28,roof);
    }else{
      make(0,high,-.04,7.33,.29,6.26,roof,true);
      make(0,high-.18,-3.15,7.36,.15,.45,trim);
      make(0,high-.21,-3.29,4.38,.40,.24,tier===4?gold:roof);
      for(const dx of [-2.65,0,2.65])make(dx,high-.27,-.8,1.03,.12,.28,['#fff2b7','#ebd08a','#d6b372']);
    }
    make(-2.15,.20,.32,1.75,.74,1.12,tier===1?wood:trim);
    make(-2.15,.94,.32,1.9,.16,1.23,tier===1?wood:gold);
    make(-1.84,1.1,.45,.55,.23,.43,metal);
    make(-1.84,1.33,.60,.46,.16,.16,teal);
    for(let i=0;i<Math.min(stock,6);i++)make(-2.62+(i%3)*.64,.20+Math.floor(i/3)*.51,1.76,.54,.50,.61,gold);
    if(tier>=2){
      make(2.13,.2,1.12,1.12,.44,2.50,trim);
      make(2.13,.64,1.12,.96,.13,2.44,roof);
      for(let i=0;i<5;i++)make(2.13,.77,.16+i*.47,.86,.045,.15,metal);
      make(2.14,.82,1.98,.55,.48,.54,teal);
      make(0,.20,2.35,3.83,.71,.60,trim);
      make(0,.91,2.35,3.92,.14,.68,wall);
    }
    if(tier>=3){
      for(const dx of [-2.43,2.43]){
        make(dx,.2,-1.82,1.16,.69,.75,trim);
        make(dx,.89,-1.82,1.27,.11,.83,teal);
        make(dx,1,-1.82,.48,.3,.4,gold);
      }
      make(0,1.64,2.42,4.26,.13,.60,wall);
      for(const dx of [-1.35,-.45,.45,1.35])make(dx,1.77,2.43,.44,.32,.42,teal);
    }
    if(tier>=4){
      make(0,3.97,-2.75,5.66,.23,.64,gold);
      for(const dx of [-3.06,3.06]){
        make(dx,.19,-3.19,.21,3.24,.28,gold);
        make(dx,3.36,-3.24,.45,.43,.42,gold);
      }
      make(0,2.47,-3.31,2.58,.10,.48,teal);
    }
    return parts;
  }
  window.ResellTycoon={mount};
})();
